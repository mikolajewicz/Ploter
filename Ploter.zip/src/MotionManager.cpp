#include "MotionManager.hpp"
#include "HomingSequence.hpp"

extern HomingSequence homingSequence;
extern void sendResponse(const char* message);
extern RTC_DATA_ATTR uint32_t lastCrashStage;

MotionManager::MotionManager(
    MotorDriver& motor1,
    TMC2209Stepper& tmc1,
    MotionExecutor& motionExecutor1,
    TrajectoryGenerator& trajectoryGenerator1,
    Homing& homing1,

    MotorDriver& motor2,
    TMC2209Stepper& tmc2,
    MotionExecutor& motionExecutor2,
    TrajectoryGenerator& trajectoryGenerator2,
    Homing& homing2,

    Kinematics& solver,

    PenController& pen
)
    : motor1(motor1),
      tmc1(tmc1),
      motionExecutor1(motionExecutor1),
      trajectoryGenerator1(trajectoryGenerator1),
      homing1(homing1),

      motor2(motor2),
      tmc2(tmc2),
      motionExecutor2(motionExecutor2),
      trajectoryGenerator2(trajectoryGenerator2),
      homing2(homing2),

      solver(solver),
      pen(pen)
{
}

bool MotionManager::A2B(
    double pointA_x,
    double pointA_y,
    double pointB_x,
    double pointB_y,
    double time,
    double timeStep
)
{
    if (!solver.A2B(
            pointA_x,
            pointA_y,
            pointB_x,
            pointB_y,
            time,
            timeStep
        )) {
        return false;
    }

    if (!solver.compute()) {
        return false;
    }

    trajectoryGenerator1.takeTrajectory(
        solver.takeMotor1Trajectory()
    );

    trajectoryGenerator2.takeTrajectory(
        solver.takeMotor2Trajectory()
    );

    trajectoryGenerator1.convertToSteps();
    trajectoryGenerator2.convertToSteps();

    std::vector<int> prepared1 =
    trajectoryGenerator1.takeStepTrajectory();

    std::vector<int> prepared2 =
        trajectoryGenerator2.takeStepTrajectory();

    xSemaphoreTake(
        trajectoryMutex,
        portMAX_DELAY
    );

    nextTrajectory1 = std::move(prepared1);
    nextTrajectory2 = std::move(prepared2);

    nextTimeStep = timeStep;
    trajectoryReady = true;

    xSemaphoreGive(trajectoryMutex);

    return true;
}

bool MotionManager::startPreparedMotion()
{
    std::vector<int> trajectory1;
    std::vector<int> trajectory2;

    double timeStep;

    xSemaphoreTake(
        trajectoryMutex,
        portMAX_DELAY
    );

    if (!trajectoryReady) {
        xSemaphoreGive(trajectoryMutex);
        return false;
    }

    trajectory1 = std::move(nextTrajectory1);
    trajectory2 = std::move(nextTrajectory2);

    timeStep = nextTimeStep;

    trajectoryReady = false;

    xSemaphoreGive(trajectoryMutex);


    motionExecutor1.start(
        std::move(trajectory1),
        timeStep
    );

    motionExecutor2.start(
        std::move(trajectory2),
        timeStep
    );

    return true;
}

bool MotionManager::isTrajectoryReady()
{
    xSemaphoreTake(
        trajectoryMutex,
        portMAX_DELAY
    );

    bool ready = trajectoryReady;

    xSemaphoreGive(trajectoryMutex);

    return ready;
}

bool MotionManager::beginPlanner()
{
    motionQueue = xQueueCreate(
        4,
        sizeof(MotionRequest)
    );

    if (motionQueue == nullptr) {
        return false;
    }

    trajectoryMutex = xSemaphoreCreateMutex();

    if (trajectoryMutex == nullptr) {
        return false;
    }

    BaseType_t result = xTaskCreatePinnedToCore(
        plannerTaskEntry,
        "MotionPlanner",
        8192,
        this,
        1,
        &plannerTaskHandle,
        0
    );

    return result == pdPASS;
}

void MotionManager::plannerTaskEntry(void* parameter)
{
    MotionManager* manager =
        static_cast<MotionManager*>(parameter);

    manager->plannerTask();
}

void MotionManager::plannerTask()
{
    MotionRequest request;

    while (true)
    {
        // Planner czeka na nowe zadanie
        lastCrashStage = 100;

        if (
            xQueueReceive(
                motionQueue,
                &request,
                portMAX_DELAY
            ) != pdTRUE
        )
        {
            continue;
        }

        lastCrashStage = 110;

        bool success = false;

        switch (request.type)
        {
            case MotionType::A2B:
            {
                lastCrashStage = 120;

                success = A2B(
                    request.pointA_x,
                    request.pointA_y,
                    request.pointB_x,
                    request.pointB_y,
                    request.value,
                    request.timeStep
                );

                lastCrashStage = 121;
                break;
            }

            case MotionType::LINE:
            {
                lastCrashStage = 200;

                success = line(
                    request.pointA_x,
                    request.pointA_y,
                    request.pointB_x,
                    request.pointB_y,
                    request.value,
                    request.timeStep
                );

                lastCrashStage = 201;
                break;
            }

            case MotionType::ARC:
            {
                lastCrashStage = 300;

                success = generateArc(
                    request.pointA_x,
                    request.pointA_y,
                    request.pointB_x,
                    request.pointB_y,
                    request.center_x,
                    request.center_y,
                    request.clockwise,
                    request.value,
                    request.timeStep
                );

                lastCrashStage = 301;
                break;
            }
        }

        lastCrashStage = 400;

        if (!success)
        {
            sendResponse(
                "Motion planning failed"
            );
        }

        lastCrashStage = 410;

        pendingPlans_.fetch_sub(1);

        lastCrashStage = 420;
    }
}

bool MotionManager::planA2B(
    double pointA_x,
    double pointA_y,
    double pointB_x,
    double pointB_y,
    double time,
    double timeStep
)
{
    if (motionQueue == nullptr) {
        return false;
    }

    MotionRequest request;

    request.type = MotionType::A2B;

    request.pointA_x = pointA_x;
    request.pointA_y = pointA_y;

    request.pointB_x = pointB_x;
    request.pointB_y = pointB_y;

    request.value = time;
    request.timeStep = timeStep;

    pendingPlans_.fetch_add(1);

    if (
        xQueueSend(
            motionQueue,
            &request,
            0
        ) != pdTRUE
    )
    {
        pendingPlans_.fetch_sub(1);
        return false;
    }

    return true;
}

bool MotionManager::line(
    double Ax,
    double Ay,
    double Bx,
    double By,
    double speed,
    double timeStep
)
{
    lastCrashStage = 101;

    if (!solver.line(
            Ax,
            Ay,
            Bx,
            By,
            speed,
            timeStep
        ))
    {
        sendResponse("DBG solver.line FAILED");
        return false;
    }

    lastCrashStage = 102;

    if (!solver.compute())
    {
        sendResponse("DBG solver.compute FAILED");
        return false;
    }

    lastCrashStage = 103;

    trajectoryGenerator1.takeTrajectory(
        solver.takeMotor1Trajectory()
    );

    lastCrashStage = 104;

    trajectoryGenerator2.takeTrajectory(
        solver.takeMotor2Trajectory()
    );

    lastCrashStage = 105;

    trajectoryGenerator1.convertToSteps();

    lastCrashStage = 106;

    trajectoryGenerator2.convertToSteps();

    lastCrashStage = 107;

    std::vector<int> prepared1 =
        trajectoryGenerator1.takeStepTrajectory();

    lastCrashStage = 108;

    std::vector<int> prepared2 =
        trajectoryGenerator2.takeStepTrajectory();

    lastCrashStage = 109;

    xSemaphoreTake(
        trajectoryMutex,
        portMAX_DELAY
    );

    nextTrajectory1 = std::move(prepared1);
    nextTrajectory2 = std::move(prepared2);

    nextTimeStep = timeStep;
    trajectoryReady = true;

    xSemaphoreGive(trajectoryMutex);

    return true;
}

bool MotionManager::generateArc(
    double pointA_x,
    double pointA_y,
    double pointB_x,
    double pointB_y,
    double center_x,
    double center_y,
    bool clockwise,
    double speed,
    double timeStep
)
{
    if (!solver.generateArc(
            pointA_x,
            pointA_y,
            pointB_x,
            pointB_y,
            center_x,
            center_y,
            clockwise,
            speed,
            timeStep
        ))
    {
        sendResponse("solver.generateArc FAILED");
        return false;
    }

    if (!solver.compute())
    {
        sendResponse("solver.compute FAILED");
        return false;
    }

    trajectoryGenerator1.takeTrajectory(
        solver.takeMotor1Trajectory()
    );

    trajectoryGenerator2.takeTrajectory(
        solver.takeMotor2Trajectory()
    );

    trajectoryGenerator1.convertToSteps();
    trajectoryGenerator2.convertToSteps();

    std::vector<int> prepared1 =
        trajectoryGenerator1.takeStepTrajectory();

    std::vector<int> prepared2 =
        trajectoryGenerator2.takeStepTrajectory();

    xSemaphoreTake(
        trajectoryMutex,
        portMAX_DELAY
    );

    nextTrajectory1 = std::move(prepared1);
    nextTrajectory2 = std::move(prepared2);

    nextTimeStep = timeStep;
    trajectoryReady = true;

    xSemaphoreGive(trajectoryMutex);

    // sendResponse("LINE READY");

    return true;
}


bool MotionManager::planLine(
    double pointA_x,
    double pointA_y,
    double pointB_x,
    double pointB_y,
    double speed,
    double timeStep
)
{
    if (motionQueue == nullptr) {
        return false;
    }

    MotionRequest request;

    request.type = MotionType::LINE;

    request.pointA_x = pointA_x;
    request.pointA_y = pointA_y;
    request.pointB_x = pointB_x;
    request.pointB_y = pointB_y;

    request.value = speed;
    request.timeStep = timeStep;

    pendingPlans_.fetch_add(1);

    if (
        xQueueSend(
            motionQueue,
            &request,
            0
        ) != pdTRUE
    )
    {
        pendingPlans_.fetch_sub(1);
        return false;
    }

    return true;

}

bool MotionManager::planArc(
    double pointA_x,
    double pointA_y,
    double pointB_x,
    double pointB_y,
    double center_x,
    double center_y,
    bool clockwise,
    double speed,
    double timeStep
)
{
    if (motionQueue == nullptr)
    {
        return false;
    }

    MotionRequest request;

    request.type = MotionType::ARC;

    request.pointA_x = pointA_x;
    request.pointA_y = pointA_y;

    request.pointB_x = pointB_x;
    request.pointB_y = pointB_y;

    request.center_x = center_x;
    request.center_y = center_y;

    request.clockwise = clockwise;

    request.value = speed;
    request.timeStep = timeStep;

    pendingPlans_.fetch_add(1);

    if (
        xQueueSend(
            motionQueue,
            &request,
            0
        ) != pdTRUE
    )
    {
        pendingPlans_.fetch_sub(1);
        return false;
    }

    return true;
}

void MotionManager::startPause(uint32_t durationMs)
{
    pauseActive = true;
    pauseStart = millis();
    pauseDuration = durationMs;
}

void MotionManager::updatePause()
{
    if (!pauseActive)
        return;

    if (millis() - pauseStart >= pauseDuration)
    {
        pauseActive = false;
    }
}

bool MotionManager::isPauseActive() const
{
    return pauseActive;
}

void MotionManager::setLiveTarget(
    double x,
    double y,
    double pressure,
    bool inside
)
{

    if (homingSequence.isActive())
    {
        clearLiveTarget();
        return;
    }

    liveTargetLastUpdate = millis();
    liveTargetInside = inside;

    if (!inside)
    {
        pen.up();
        return;
    }

    // Zapamiętujemy tylko ostatni POPRAWNY punkt.
    liveTargetX = x;
    liveTargetY = y;

    livePressure = pressure;
    liveTargetReceived = true;

    pen.setPressure(pressure);
}


bool MotionManager::calculateCurrentPosition(){
    double m1_steps = motor1.getStepCount();
    double m2_steps = motor2.getStepCount();

    unsigned int stepsPerRev = trajectoryGenerator1.getStepsPerRev();

    double m1_angle = m1_steps / stepsPerRev * 360;
    double m2_angle = m2_steps / stepsPerRev * 360;

    return solver.forwardKinematics(m1_angle, m2_angle, current_x, current_y);

  
}

bool MotionManager::followTarget()
{
    if (
        !liveTargetReceived ||
        millis() - liveTargetLastUpdate > 500
    )
    {
        current_speed = 0.0;
        line_vect_x = 0.0;
        line_vect_y = 0.0;

        return false;
    }

    double mass = 1.0;
    double stiffness = 500.0;
    double viscocity = 3 * std::sqrt(mass * stiffness);
    double move_time = 0.01;

    if (!calculateCurrentPosition())
    {
        return false;
    }

    constexpr double X_MAX = 138.5;
    constexpr double Y_MAX = 95.0;
    constexpr double MAX_SPEED = 500.0; // mm/s
    constexpr double MAX_ACCELERATION = 2000.0; // mm/s^2

    double target_x = constrain(
        liveTargetX,
        -X_MAX,
        X_MAX
    );

    double target_y = constrain(
        liveTargetY,
        -Y_MAX,
        Y_MAX
    );

    double previous_distance =
        std::hypot(
            line_vect_x,
            line_vect_y
        );

    double speed_x = 0.0;
    double speed_y = 0.0;

    if (previous_distance > 0.000001)
    {
        speed_x =
            current_speed
            * line_vect_x
            / previous_distance;

        speed_y =
            current_speed
            * line_vect_y
            / previous_distance;
    }

    double distance_x =
        target_x - current_x;

    double distance_y =
        target_y - current_y;

    double distance =
        std::hypot(
            distance_x,
            distance_y
        );

    if (distance < 0.0)
    {
        current_speed = 0.0;
        line_vect_x = 0.0;
        line_vect_y = 0.0;

        return false;
    }

    double acceleration_x =
    (
        -viscocity * speed_x
        + stiffness * distance_x
    )
    / mass;

    double acceleration_y =
        (
            -viscocity * speed_y
            + stiffness * distance_y
        )
        / mass;


// --------------------------------------------------
// Limit przyspieszenia
// --------------------------------------------------

    
    double acceleration =
        std::hypot(
            acceleration_x,
            acceleration_y
        );

    if (acceleration > MAX_ACCELERATION)
    {
        double scale =
            MAX_ACCELERATION / acceleration;

        acceleration_x *= scale;
        acceleration_y *= scale;
    }


    // --------------------------------------------------
    // Aktualizacja prędkości
    // --------------------------------------------------

    speed_x +=
        acceleration_x * move_time;

    speed_y +=
        acceleration_y * move_time;


    // --------------------------------------------------
    // Limit prędkości
    // --------------------------------------------------

    double speed =
        std::hypot(
            speed_x,
            speed_y
        );

    if (speed > MAX_SPEED)
    {
        double scale =
            MAX_SPEED / speed;

        speed_x *= scale;
        speed_y *= scale;
    }

    current_speed =
        std::hypot(
            speed_x,
            speed_y
        );

    double new_distance_x =
        speed_x * move_time;

    double new_distance_y =
        speed_y * move_time;

    double next_x = constrain(
        current_x + new_distance_x,
        -X_MAX,
        X_MAX
    );

    double next_y = constrain(
        current_y + new_distance_y,
        -Y_MAX,
        Y_MAX
    );

    static uint32_t lastDebug = 0;

    new_distance_x =
        next_x - current_x;

    new_distance_y =
        next_y - current_y;

    if (
        std::hypot(
            new_distance_x,
            new_distance_y
        ) < 0.001
    )
    {
        current_speed = 0.0;
        line_vect_x = 0.0;
        line_vect_y = 0.0;

        return false;
    }

    line_vect_x = new_distance_x;
    line_vect_y = new_distance_y;

    return line(
        current_x,
        current_y,
        next_x,
        next_y,
        current_speed,
        0.0005
    );
}

void MotionManager::clearLiveTarget()
{
    liveTargetReceived = false;
    liveTargetInside = false;

    current_speed = 0.0;
    line_vect_x = 0.0;
    line_vect_y = 0.0;

    pen.up();
}

bool MotionManager::canPlanNext()
{
    return
        !isPlanning() &&
        !isTrajectoryReady();
}

bool MotionManager::isBusy()
{
    return
        isPlanning() ||
        isTrajectoryReady() ||
        motionExecutor1.isActive() ||
        motionExecutor2.isActive() ||
        isPauseActive();
}

bool MotionManager::isPlanning() const
{
    return pendingPlans_.load() > 0;
}

void MotionManager::clearPreparedMotion()
{
    if (trajectoryMutex == nullptr)
    {
        return;
    }

    xSemaphoreTake(
        trajectoryMutex,
        portMAX_DELAY
    );

    nextTrajectory1.clear();
    nextTrajectory2.clear();

    trajectoryReady = false;

    xSemaphoreGive(
        trajectoryMutex
    );
}



