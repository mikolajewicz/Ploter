#pragma once

#include <TMCStepper.h>

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <freertos/semphr.h>

#include "MotorDriver.hpp"
#include "MotionExecutor.hpp"
#include "TrajectoryGenerator.hpp"
#include "Homing.hpp"
#include "Kinematics.hpp"
#include "PenController.hpp"

#include <vector>
#include <atomic>


class MotionManager
{
private:
    MotorDriver& motor1;
    TMC2209Stepper& tmc1;
    MotionExecutor& motionExecutor1;
    TrajectoryGenerator& trajectoryGenerator1;
    Homing& homing1;

    MotorDriver& motor2;
    TMC2209Stepper& tmc2;
    MotionExecutor& motionExecutor2;
    TrajectoryGenerator& trajectoryGenerator2;
    Homing& homing2;

    Kinematics& solver;

    PenController& pen;

    std::vector<int> nextTrajectory1;
    std::vector<int> nextTrajectory2;

    double nextTimeStep = 0.01;

    bool trajectoryReady = false;

    enum class MotionType
    {
        A2B,
        LINE,
        ARC
    };

    struct MotionRequest
    {
        MotionType type;

        double pointA_x;
        double pointA_y;

        double pointB_x;
        double pointB_y;

        double center_x;
        double center_y;

        bool clockwise;

        // A2B -> time
        // LINE -> speed
        // ARC -> speed
        double value;

        double timeStep;
    };

    QueueHandle_t motionQueue = nullptr;
    TaskHandle_t plannerTaskHandle = nullptr;
    SemaphoreHandle_t trajectoryMutex = nullptr;

    static void plannerTaskEntry(void* parameter);
    void plannerTask();

    double liveTargetX = 0.0;
    double liveTargetY = 0.0;

    double livePressure = 0.0;

    bool liveTargetInside = false;
    bool liveTargetReceived = false;

    uint32_t liveTargetLastUpdate = 0;

    double current_x = 0.0;
    double current_y = 0.0;

    double current_speed = 0;

    double line_vect_x = 0;
    double line_vect_y = 0;

    bool pauseActive = false;
    uint32_t pauseStart = 0;
    uint32_t pauseDuration = 0;

    std::atomic<uint32_t> pendingPlans_{0};

public:
    MotionManager(
        MotorDriver& motor1,
        TMC2209Stepper& tmc1,
        MotionExecutor& motionExecutor1,
        TrajectoryGenerator& trajectoryGenerator1,
        Homing& homing1,

        MotorDriver& motor2,
        TMC2209Stepper& tmc2,
        MotionExecutor& motionExecutor2,
        TrajectoryGenerator& trajectoryGenerator2,
        Homing& homing2,

        Kinematics& solver,

        PenController& pen
    );

    bool A2B(
        double pointA_x,
        double pointA_y,
        double pointB_x,
        double pointB_y,
        double time,
        double timeStep = 0.01
    );

    bool line(
        double pointA_x,
        double pointA_y,
        double pointB_x,
        double pointB_y,
        double speed, // mm/s
        double timeStep = 0.01);

    bool generateArc(
        double pointA_x,
        double pointA_y,
        double pointB_x,
        double pointB_y,
        double center_x,
        double center_y,
        bool clockwise,
        double speed, // mm/s
        double timeStep = 0.01);
    
    bool startPreparedMotion();

    bool isTrajectoryReady();

    bool beginPlanner();

    bool planA2B(
        double pointA_x,
        double pointA_y,
        double pointB_x,
        double pointB_y,
        double time,
        double timeStep
    );

    bool planLine(
        double pointA_x,
        double pointA_y,
        double pointB_x,
        double pointB_y,
        double speed,
        double timeStep
    );

    bool planArc(
        double pointA_x,
        double pointA_y,
        double pointB_x,
        double pointB_y,
        double center_x,
        double center_y,
        bool clockwise,
        double speed,
        double timeStep
    );

    void setLiveTarget(
        double x,
        double y,
        double pressure,
        bool inside
    );

    bool calculateCurrentPosition();
    double getCurrentX(){ return current_x; }
    double getCurrentY(){ return current_y; }

    bool followTarget();

    void clearLiveTarget();

    void penUp(){ pen.up(); }
    void penDown(){ pen.down(); }

    void startPause(uint32_t durationMs);
    void updatePause();
    bool isPauseActive() const;

    bool isPlanning() const;
    bool canPlanNext();
    bool isBusy();

    void clearPreparedMotion();
};

