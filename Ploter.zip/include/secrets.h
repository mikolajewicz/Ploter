#pragma once

#define WIFI_SSID "ASUS-MIKOLAJ"
#define WIFI_PASSWORD "mikolaj123"
#define OTA_PASSWORD "mikolaj123"